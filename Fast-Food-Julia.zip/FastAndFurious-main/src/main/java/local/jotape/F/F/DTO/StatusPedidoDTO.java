package local.jotape.F.F.DTO;

import local.jotape.F.F.domain.model.StatusPedido;

public class StatusPedidoDTO {

    private StatusPedido status;

    public StatusPedido getStatus() {
        return status;
    }

    public void setStatus(StatusPedido status) {
        this.status = status;
    }

}
