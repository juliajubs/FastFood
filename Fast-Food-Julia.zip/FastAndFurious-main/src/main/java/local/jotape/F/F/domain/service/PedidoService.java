package local.jotape.F.F.domain.service;

import java.math.BigDecimal;
import local.jotape.F.F.domain.model.Pedido;
import local.jotape.F.F.domain.model.StatusPedido;
import local.jotape.F.F.domain.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import local.jotape.F.F.domain.model.Produto;
import local.jotape.F.F.domain.repository.ProdutoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import static org.springframework.http.ResponseEntity.ok;
import org.springframework.web.server.ResponseStatusException;

@Service
public class PedidoService {

    @Autowired
    private ProdutoRepository produtoRepository;

    @Autowired
    private PedidoRepository pedidoRepository;

    public Pedido criar(Pedido pedido) {
        List<Long> idsProdutos = pedido.getProdutos().stream()
                .map(Produto::getId)
                .collect(Collectors.toList());

        List<Produto> produtosCompletos = produtoRepository.findAllById(idsProdutos);

        if (produtosCompletos.size() != idsProdutos.size()) {
            throw new IllegalArgumentException("Alguns produtos não foram encontrados no banco!");
        }

        BigDecimal precoTotal = produtosCompletos.stream()
                .map(prod -> BigDecimal.valueOf(prod.getPreco()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        pedido.setProdutos(produtosCompletos);
        pedido.setPreco(precoTotal);
        pedido.setStatus(StatusPedido.ABERTO);
        pedido.setDataAbertura(LocalDateTime.now());

        return pedidoRepository.save(pedido);
    }

    public List<Pedido> findAll() {
        List<Pedido> pedidos = pedidoRepository.findAll();

        if (pedidos.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Ainda não existem pedidos!");
        }

        return pedidos;
    }

    public Optional<Pedido> findById(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado!"));

        return pedidoRepository.findById(id);
    }

    public List<Pedido> findByStatus(StatusPedido status) {
        return pedidoRepository.findByStatus(status);
    }

    public Pedido finalizarPedido(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado!"));

        pedido.setStatus(StatusPedido.PRONTO);
        pedido.setDataFinalizacao(LocalDateTime.now());

        return pedidoRepository.save(pedido);
    }

    public Pedido alterarStatus(Long id, StatusPedido novoStatus) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado!"));

        // Impede alteração se o pedido já estiver finalizado ou cancelado
        if (pedido.getStatus() == StatusPedido.ENTREGUE || pedido.getStatus() == StatusPedido.CANCELADO) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Não é possível alterar o status de um pedido entregue ou cancelado.");
        }

        pedido.setStatus(novoStatus);

        if (novoStatus == StatusPedido.PRONTO || novoStatus == StatusPedido.CANCELADO) {
            pedido.setDataFinalizacao(LocalDateTime.now());
        } else if (novoStatus == StatusPedido.ENTREGUE) {
            pedido.setDataEntrega(LocalDateTime.now());
        }

        return pedidoRepository.save(pedido);
    }

    public Pedido atualizarPedido(Long id, Pedido pedidoAtualizado) {
        Pedido pedidoExistente = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado!"));

        if (pedidoAtualizado.getDescricao() != null) {
            pedidoExistente.setDescricao(pedidoAtualizado.getDescricao());
        }

        if (pedidoAtualizado.getProdutos() != null && !pedidoAtualizado.getProdutos().isEmpty()) {
            List<Long> idsProdutos = pedidoAtualizado.getProdutos().stream()
                    .map(Produto::getId)
                    .collect(Collectors.toList());

            List<Produto> produtosCompletos = produtoRepository.findAllById(idsProdutos);

            if (produtosCompletos.size() != idsProdutos.size()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Alguns produtos não foram encontrados!");
            }

            pedidoExistente.setProdutos(produtosCompletos);

            BigDecimal precoTotal = produtosCompletos.stream()
                    .map(prod -> BigDecimal.valueOf(prod.getPreco()))
                    .reduce(BigDecimal.ZERO, BigDecimal::add);

            pedidoExistente.setPreco(precoTotal);
        }

        return pedidoRepository.save(pedidoExistente);
    }

    public ResponseEntity<String> deletar(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Pedido não encontrado"));
        pedidoRepository.delete(pedido);

        return ResponseEntity.ok("Deletado com sucesso!");
    }
}
