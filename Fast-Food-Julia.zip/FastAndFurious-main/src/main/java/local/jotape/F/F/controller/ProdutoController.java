package local.jotape.F.F.controller;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;
import local.jotape.F.F.domain.model.Produto;
import local.jotape.F.F.domain.repository.ProdutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/produto")
public class ProdutoController {

    @PersistenceContext
    private EntityManager manager;

    @Autowired
    private ProdutoRepository produtoRepository;

    @GetMapping
    public List<Produto> listar() {
        return produtoRepository.findAll();
    }

    @GetMapping("/nome/{nome}")
    public List<Produto> buscarPorNome(@PathVariable String nome) {
        List<Produto> produtos = produtoRepository.findByNomeContainingIgnoreCase(nome);

        if (produtos.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Esse produto não existe!");
        }

        return produtos;
    }

    @GetMapping("/cat/{categoria}")
    public List<Produto> buscarPorCategoria(@PathVariable String categoria) {
        List<Produto> produtos = produtoRepository.findByCategoriaContainingIgnoreCase(categoria);

        if (produtos.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Categoria não encontrada!");
        }

        return produtos;
    }

    @GetMapping("/{produtoID}")
    public ResponseEntity<Produto> buscar(@PathVariable Long produtoID) {

        Optional<Produto> produto = produtoRepository.findById(produtoID);

        if (produto.isPresent()) {
            return ResponseEntity.ok(produto.get());
        } else {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Esse produto não existe!");
        }
    }

    @PostMapping
    public ResponseEntity<String> adicionar(@Valid @RequestBody Produto produto) {
        produtoRepository.save(produto);
        return ResponseEntity.status(HttpStatus.CREATED).body("Produto criado com sucesso!!");
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produto> atualizar(@Valid @PathVariable Long id, @RequestBody Produto dados) {
        Optional<Produto> optionalProduto = produtoRepository.findById(id);
        if (optionalProduto.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Produto produto = optionalProduto.get();

        if (dados.getNome() != null) {
            produto.setNome(dados.getNome());
        }
        if (dados.getPreco() != null) {
            produto.setPreco(dados.getPreco());
        }
        if (dados.getCategoria() != null) {
            produto.setCategoria(dados.getCategoria());
        }

        produtoRepository.save(produto);
        return ResponseEntity.ok(produto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable(name = "id") Long produtoID) {

        //Verifica se o produto existe ou não
        if (!produtoRepository.existsById(produtoID)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Esse produto não exist!e");
        }

        produtoRepository.deleteById(produtoID);
        throw new ResponseStatusException(HttpStatus.OK, "Deletado com sucesso!");
    }
}
