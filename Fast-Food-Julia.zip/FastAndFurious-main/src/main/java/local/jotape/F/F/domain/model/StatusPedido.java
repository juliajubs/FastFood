package local.jotape.F.F.domain.model;

public enum StatusPedido {
    
    ABERTO, PRONTO, ENTREGUE, CANCELADO;
}
